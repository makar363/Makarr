class Debugger:
    @staticmethod
    def error(message):
        print("[ERROR]", message)

    @staticmethod
    def warning(message):
        print("[WARNING]", message)