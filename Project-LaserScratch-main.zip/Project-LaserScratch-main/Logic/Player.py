

class Players:
	ClientDict = {}
	Major = 0
	Minor = 0
	Revision = 0
	BattleTick = 0
	

	def __init__(self, device):
		self.device = device
