<h1 align="center">Laser Scratch</h1>

Brawl Stars open source server for v20!


![ScreenShot](https://cdn.discordapp.com/attachments/914412016100315187/915434728625152030/Screenshot_20211130-235016.png) 


## Implemented Features
  - Battle End
  - Leaderboard
  - Player Profile
  - Lobby Info
  - Menu Notifications
  - Club Wars


## Important Notes
  - Python 3.7 is the minimum requirement to run the server.
  - This server was made ONLY for testing purposes. If you aren't a coder, don't try to use it.
  - Missing features should be added in future.
  - The server doesn't have his own client yet. A custom client will be available soon.


## Authors
👤 **Isadora**
* Github: [@Isaa](https://github.com/IsaaSooBarr)


Contributors:
- PhoenixFire
- Crazor
- BreadDev
- XshadowX
- Peter
- Peka
- eesdf
